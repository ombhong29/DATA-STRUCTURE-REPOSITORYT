<!DOCTYPE html>
<html lang="en" dir="ltr">

     <style type="text/css">

		.header {
		  overflow: hidden;
		  background-color: #10151b;
		  padding: 10px 30px ;
		}
		
		.header a {
		  float: left;
		  color: white;
		  text-align: center;
		  padding: 12px;
		  text-decoration: none;
		  font-size: 18px; 
		  line-height: 25px;
		  border-radius: 4px;
		}
		
		.header a.logo {
		  font-size: 25px;
		  font-weight: bold;
		}
		.header a.logo:hover {
		  background-color: black;
		}

		.header a:hover {
		  background-color: rgb(86, 246, 11);
		  color: black;
		}
		
		.header a.active {
		  background-color: dodgerblue;
		  color: white;
		}
		
		.header-right {
		  float: right;
		}
		.subnav {
		  float: left;
		  overflow: hidden;
		  padding: 12px;
		  text-decoration: none;
		  font-size: 18px; 
		  line-height: 25px;
		  border-radius: 4px;
		}
		
		.subnav .subnavbtn {
		  border: none;
		  outline: none;
		  color: white;
		
		  background-color: inherit;
		  font-family: inherit;
		  margin: 0;
		}
		
		
		.subnav-content {
		  display: none;
		  position: absolute;
		
		  background-color: black;
		  z-index: 1;
		}
		
		.subnav-content a {
		  float: left;
		  color: white;
		  text-decoration: none;
		}
		
		.subnav-content a:hover {
		  background-color: rgb(6, 240, 26);
		  color: black;
		}
		
		.subnav:hover .subnav-content {
		  display: block;
		}

    
</style>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Government Schemes</title>
    <link rel="stylesheet" href="govts/indexamd.css">
    <link rel="buttonscrpt" href="govts/topbutton.js">

</head>
<body>
    <a class="top-link hide" href="" id="js-top">

    <span class="screen-reader-text">Back to Top</span>
  </a>
</body>



<!-- Start mainmenu -->
<header>
	<div class="header">
	 <a href="index.html" class="logo"><img style="height: 80px;" src="images/footer-logo.png" alt="logo"></a>
	 <br>
	  <div class="header-right">
      
        <a style="font-size: larger;" href="index.html">Home</a>
     
	   <div class="subnav">
		   <button style="font-size: larger;" class="subnavbtn">Weather<i class="#"></i></button>
		   <div class="subnav-content">
		   <li><a href="weatherwebsite/index.html">Search</a></li>
		   <li><a href="weatherwebsite/currentLocationW/index.html">Your Current Location</a></li>
		   </div>
	   </div>
	   <div class="subnav">
		   <button style="font-size: larger;" class="subnavbtn">Seeds<i class="#"></i></button>
		   <div class="subnav-content">
		   <li><a href="seed.html">Info on Seeds</a></li>
		   <li><a href="seed price.html">Current Seeds Price</a></li>
       <li><a href="Fertilizer.html">Fertilizer</a></li>
		   </div>
	   </div>
	   <div class="subnav">
      <button style="font-size: larger;" class="subnavbtn">Tech Knowledge<i class="#"></i></button>
      <div class="subnav-content">
      <li><a href="solarpanel.html">Farming Resources</a></li>
      <li><a href="tech.html">IOT</a></li>
      </div>
    </div>
     <a style="font-size: larger;" href="Feedback.html">Feedback</a>
	   </div>
</div>

</header>
<!-- End mainmenu -->

<!-- <div class="entire" style="color: aliceblue;">

     <h1 >
      <b>GOVERMENT SCHEMES FOR FARMERS</b>
     </h1>

</div> -->

<div class="boxx">


    <p>The government has introduced various schemes for the security of the farmers and the development of the <br>
      agricultural sector. <br>
      Some of the schemes devised by the central government are :
      <header>
        <div style="background-color:#c0c0c0" class="header">
         <br>
          <div style="float: left;" class="header-right">
            <a style="color: black;" href="#1 "> E-NAM</a>
    <a style="color: black;" href="#2 "> NMSA</a>
    <a style="color: black;" href="#3 "> PMKSY</a>
    <a style="color: black;" href="#4 "> PKVY</a>
    <a style="color: black;" href="#5 "> PMFBY</a>
    <a style="color: black;" href="#6 "> MIF</a>
    <a style="color: black;" href="#7 "> KCC</a>
    <a style="color: black;" href="#8 "> AIF</a>
    <a style="color: black;" href="#9 "> NFSM</a>
    <a style="color: black;" href="#10"> MIDH</a>
    <a style="color: black;" href="#11"> SMAM</a>
           </div>
      </div>
      
      </header>
    
</p>

</div>

    <br>
    <div class="boxx">
     <h3 id="1">National Agricultural Market  (E-NAM)</h3>
     <h4>OVERVIEW</h4>
     <p>
        Launched in : <i>APRIL 2016</i> <br><br>
       National Agriculture Market (eNAM) is a pan-India electronic trading portal which networks the existing APMC mandis to create a unified national market for agricultural commodities.
       <br>
       <br>
       Small Farmers Agribusiness Consortium (SFAC) is the lead agency for implementing eNAM under the aegis of Ministry of Agriculture and Farmers’ Welfare, Government of India.
       <br>
       <br>
       Goal is to promote uniformity in agriculture marketing by streamlining of procedures across the integrated markets, removing information asymmetry between buyers and sellers and promoting real time price discovery based on actual demand and supply.
     </p>
     <a href="https://www.enam.gov.in/web/ " target="_blank"> OFFICIAL WEBSITE</a><br><br>

    <div class="video">

     <iframe width=" " height=" " src="https://www.youtube.com/embed/6okFG0gGAXE" title="YouTube video player" frameborder="2" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
    </div></div>
<br>
<br>

<div class="boxx">
     <h3 id="2">National Mission For Sustainable Agriculture (NMSA)</h3>
     <h4>OVERVIEW</h4>
     <p>
       Launched in: <i>2015</i><br><br>
       National Mission for Sustainable Agriculture (NMSA) has been formulated for enhancing agricultural productivity especially in rainfed areas focusing on integrated farming, water use efficiency, soil health management and synergizing resource conservation.
     <br>
     <br>
     The strategies and programmers of actions (POA) outlined in the Mission Document, that was accorded ‘in principle’ approval by Prime Minister’s Council on Climate Change (PMCCC) on 23.09.2010,aim at promoting sustainable agriculture through a series of adaptation measures focusing on ten key dimensions encompassing Indian agriculture namely; ‘Improved crop seeds, livestock and fish cultures’, ‘Water Use Efficiency’, ‘Pest Management’, ‘Improved Farm Practices’, ‘Nutrient Management’, ‘Agricultural insurance’, ‘Credit support’, ‘Markets’, ‘Access to Information’ and ‘Livelihood diversification’.
 </p>
     <a href="https://nmsa.dac.gov.in/ " target="_blank"> OFFICIAL WEBSITE</a><br><br>
<div class="video">
    <iframe width=" " height=" " src="https://www.youtube.com/embed/DS_SMVvqzsg" title="YouTube video player" frameborder="2" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
    </div></div>
<br>
<br>
<div class="boxx">
     <h3 id="3">Pradhan Mantri Krishi Sinchai Yojana (PMKSY)</h3>
     <h4>OVERVIEW</h4>
     <p>
       Launched in : <i>January 2006</i><br><br>
       The Government of India has been implementing Centrally Sponsored Scheme on Micro Irrigation with the objective to enhance water use efficiency in the agriculture sector by promoting appropriate technological interventions like drip & sprinkler irrigation technologies and encourage the farmers to use water saving and conservation technologies.
       <br>
       <br>
       To this effect Pradhan Mantri Krishi Sinchayee Yojana (PMKSY) has been formulated with the vision of extending the coverage of irrigation ‘Har Khet ko pani’ and improving water use efficiency ‘More crop per drop' in a focused manner with end to end solution on source creation, distribution, management, field application and extension activities.
       <br><br>

     </p>
     <a href=" https://pmksy.gov.in/" target="_blank"> OFFICIAL WEBSITE</a><br><br>
<div class="video">
     <iframe width=" " height=" " src="https://www.youtube.com/embed/FeS_btDFkRA" title="YouTube video player" frameborder="2" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
     </div></div>
<br>
<br>
<div class="boxx">
      <h3 id="4">Paramparagat Krishi Vikas Yojna (PKVY)</h3>
      <h4>OVERVIEW</h4>
      <p>
        launched in: <i>2015</i><br><br>
         It aims at development of sustainable models of organic farming through a mix of traditional wisdom and modern science to ensure long term soil fertility buildup, resource conservation and helps in climate change adapatation and mitigation.
         <br><br>
         PKVY also aims at empowering farmers through institutional development through clusters approch not only in farm practice management,input production,quality assurance but also in value addition and direct marketing through innovative means.
         <br><br>

      </p>
     <a href=" https://pgsindia-ncof.gov.in/PKVY/Introduction.aspx" target="_blank"> OFFICIAL WEBSITE</a><br><br>
<div class="video">
     <iframe width=" " height=" " src="https://www.youtube.com/embed/_JTaN927MKc" title="YouTube video player" frameborder="2" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe></div>
     </div>
<br>
<br>
<div class="boxx">
     <h3 id="5">Pradhan Mantri Fasal Bima Yojana (PMFBY)</h3>
     <h4>OVERVIEW</h4>
     <p>
       Launched in : <i>February 2016</i><br><br>
       Crop Insurance is an integrated IT solution and a web-based ecosystem to speed up service delivery, unify fragmented databases, achieve a single view of data, and eliminate manual processes. Crop Insurance provides insurance services to farmers faster than before.
       <br><br>
       This is a stable, secure and seamlessly integrated ecosystem created with a comprehensive view of data in a secure environment thereby enabling information access to multiple stakeholders viz. Farmers, Govt. Functionaries, Insurance Companies, Intermediaries, Bankers and social & community bodies.
       <br><br>
       Crop Insurance portal has enabled the digitization of notification of areas, crops, schemes for enabling information access to multiple stakeholders thereby facilitating ease of access to the farmers in availing crop insurance services. This automated solution has opened a window of opportunity to remote and economically-weak farmers to benefit from crop insurance services.

     </p>
     <a href=" https://pmfby.gov.in/" target="_blank"> OFFICIAL WEBSITE</a><br><br>
<div class="video">
     <iframe width=" " height=" " src="https://www.youtube.com/embed/IGQ3EgCeoXg" title="YouTube video player" frameborder="2" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe></div>
     </div>
<br>
<br>
<div class="boxx">
     <h3 id="6">Micro Irrigation Fund (MIF)</h3>
     <h4>OVERVIEW</h4>
     <p>
  Launched in : <i>2016</i><br><br>
  The Department of Agriculture, Cooperation & Farmers Welfare (DAC&FW) is implementing a Centrally Sponsored Scheme of  ‘Per Drop More Crop’ component of ‘Pradhan Mantri Krishi Sinchayee Yojana (PMKSY-PDMC)’ from  2015-16 in all the States of the country which  focuses on enhancing water use efficiency at farm level through Micro Irrigation viz. Drip and Sprinkler irrigation systems.
<br>
<br>
Recent evaluation studies of the scheme indicate that the coverage of Micro Irrigation is relevant in achieving national priorities such as substantially improving on-farm water use efficiency, enhancing crop productivity, ensuring better returns to farmers, generating employment opportunities etc.  Further, the scheme has been effective in terms of ensuring benefits for farmers e.g. higher productivity; reduction in labour cost, water consumption, power utilization, fertilizer use etc.<br><br>
<div class="video">
<iframe width=" " height=" " src="https://www.youtube.com/embed/bF9dEvYwG9U" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe></div>
</div>
<br>
<br></p>
<div class="boxx">
     <h3 id="7">e-Kisan Credit Card (KCC)</h3>
     <h4>OVERVIEW</h4>
     <p>
       Launched in:<i>1998</i><br><br>
       The Kisan Credit Card (KCC) scheme was introduced in 1998 for issue of Kisan Credit Cards to farmers on the basis of their holdings for uniform adoption by the banks so that farmers may use them to readily purchase agriculture inputs such as seeds, fertilizers, pesticides etc. and draw cash for their production needs.
       <br><br>
       The Kisan Credit Card Scheme is to be implemented by Commercial Banks, RRBs, Small Finance Banks and Cooperatives.
       <br><br>
       The Kisan Credit Card scheme aims at providing adequate and timely credit support from the banking system under a single window with flexible and simplified procedure to the farmers for their cultivation and other needs as indicated below:

       <li>To meet the short term credit requirements for cultivation of crops</li>
       <li>Post-harvest expenses</li>
       <li>Produce marketing loan</li>
       <li>Consumption requirements of farmer household;</li>
       <li>Working capital for maintenance of farm assets and activities allied to agriculture</li>
       <li>Investment credit requirement for agriculture and allied activities.</li>
     </p><div class="video">
<iframe width=" " height=" " src="https://www.youtube.com/embed/OKs9kbLlDzw" title="YouTube video player" frameborder="2" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe></div>
</div>
<br>
<br>
<div class="boxx">
     <h3 id="8">Agriculture Infrastructure Fund (AIF)</h3>

     <h4>OVERVIEW</h4>
     <p>
       Launched in: <i>2020</i><br><br>
       The role of infrastructure is crucial for agriculture development and for taking the
production dynamics to the next level. It is only through the development of infrastructure,
especially at the post harvest stage that the produce can be optimally utilized with opportunity
for value addition and fair deal for the farmers
<br><br>
       It was launched in 2020 as a part of the Rs. 20 lakh crore stimulus package announced in response to the Covid-19 crisis.
       <br><br>

     </p>
<div class="video">
     <iframe width="" height="" src="https://www.youtube.com/embed/EZ-rKoNq7Tw" title="YouTube video player" frameborder="02" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe></div>
     </div>
<br>
<br>
<div class="boxx">
     <h3 id="9">National Food Security Mission (NFSM)</h3>
     <h4>OVERVIEW</h4>
     Launched in: <i> OCTOBER 2007</i><br><br>
     The National Development Council (NDC) in its 53rd meeting held on 29th May, 2007 adopted a resolution to launch a Food Security Mission comprising rice, wheat and pulses to increase the annual production of rice by 10 million tonnes, wheat by 8 million tonnes and pulses by 2 million tonnes by the end of the Eleventh Plan (2011-12). Accordingly, a Centrally Sponsored Scheme, 'National Food Security Mission' (NFSM), was launched in October 2007.
     <br><br>
     The Mission met with an overwhelming success and achieved the targeted additional production of rice, wheat and pulses. The Mission continued during 12th Five Year Plan with new targets of additional production of food grains of 25 million tonnes of food grains comprising of 10 million tonnes rice, 8 million tonnes of wheat, 4 million tonnes of pulses and 3 million tonnes of coarse cereals by the end of 12th Five Year Plan.<br><br>

     <a href=" https://www.nfsm.gov.in" target="_blank"> OFFICIAL WEBSITE</a><br><br>
     </div>




<br>
<br>
<div class="boxx">
     <h3 id="10">Mission for Integrated Development of Horticulture (MIDH)</h3>
     <h4>OVERVIEW</h4>
     Launched in: <i>2022</i>
     <br><br>
     Mission for Integrated Development of Horticulture (MIDH) is a Centrally Sponsored Scheme for the holistic growth of the horticulture sector covering fruits, vegetables, root & tuber crops, mushrooms, spices, flowers, aromatic plants, coconut, cashew, cocoa and bamboo
     <br><br>
     nder MIDH, Government of India (GOI) contributes 60%, of total outlay for developmental programmes in all the states except states in North East and Himalayas, 40% share is contributed by State Governments. In the case of North Eastern States and Himalayan States, GOI contributes 90%
     <br>
     <a href="https://midh.gov.in " target="_blank"> OFFICIAL WEBSITE</a><br><br>
<div class="video">
     <iframe width="" height="" src="https://www.youtube.com/embed/1s_Kt3fWTIk" title="YouTube video player" frameborder="2" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe></div>
     </div>
<br>
<br>
<div class="boxx">
     <h3 id="11">Sub Mission on Agriculture Mechanization (SMAM)</h3>
     <h4>OVERVIEW</h4>
     Launched in: <i>2015</i><br><br>
     Ministry of Agriculture and Farmers Welfare has launched a Sub-Mission on Agricultural Mechanization (SMAM) in 2014-15 with the objectives of increasing the reach of farm mechanization to small and marginal farmers and to the regions & difficult area where farm power availability is low.
     <br><br>

    To boost up mechanization in the agriculture sector improved agricultural implements and machinery are essential inputs for modern agriculture that enhance the productivity of crops besides reducing human drudgery and cost of cultivation. Mechanization also helps in improving the utilization efficiency of other inputs therefore considered to be one of the most important segments of the agriculture sector to boost the income of farmers and growth of the agricultural economy.
    <br><br>
    For strengthening of agricultural mechanization in the country and to bring more inclusiveness Sub-Mission on Agricultural Mechanization (SMAM) has been introduced with the main objectives of are to promote ‘Custom Hiring Centres’ and ‘Hi-tech Hubs of High-Value Machines’ to offset the adverse economies of scale arising due to small and fragmented landholding and high cost of individual ownership; Creating awareness among stakeholders through demonstration and capacity building activities and ensuring performance testing and certification of agricultural machines at designated testing centres located all over the country.
    <br><br><div class="video">
<iframe width="" height="" src="https://www.youtube.com/embed/QDBtsiy8AMY" title="YouTube video player" frameborder="02" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe></div>
</div><br><br>

</div>
more to be added .....
  </body>
</html>
